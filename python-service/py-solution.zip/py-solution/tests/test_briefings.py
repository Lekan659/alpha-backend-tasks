import uuid
from datetime import date
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from app.schemas.briefing import BriefingCreate, BriefingUpdate, BriefingMetricInput, BriefingPointInput
from app.services.briefing_service import (
    BriefingAlreadyPublishedError,
    BriefingNotFoundError,
    briefing_to_read_schema,
)


class TestBriefingSchemas:
    """Test Pydantic schema validation."""

    def test_valid_briefing_create(self):
        """Valid briefing creation data should pass validation."""
        data = BriefingCreate(
            company_name="Acme Corp",
            ticker="acme",
            report_date=date(2024, 1, 15),
            analyst_name="John Doe",
            key_points=[
                BriefingPointInput(content="Strong revenue growth"),
                BriefingPointInput(content="Expanding market share"),
            ],
            risks=[
                BriefingPointInput(content="Regulatory uncertainty"),
            ],
            metrics=[
                BriefingMetricInput(metric_name="Revenue", metric_value="1.5B", metric_unit="USD", period="Q4 2023"),
            ],
        )
        assert data.company_name == "Acme Corp"
        assert data.ticker == "ACME"  # Should be uppercased

    def test_ticker_is_uppercased(self):
        """Ticker should be automatically uppercased."""
        data = BriefingCreate(
            company_name="Test",
            report_date=date.today(),
            key_points=[
                BriefingPointInput(content="Point 1"),
                BriefingPointInput(content="Point 2"),
            ],
            risks=[BriefingPointInput(content="Risk 1")],
            ticker="lowercase",
        )
        assert data.ticker == "LOWERCASE"

    def test_minimum_key_points_required(self):
        """At least 2 key points are required."""
        with pytest.raises(ValidationError) as exc_info:
            BriefingCreate(
                company_name="Test",
                report_date=date.today(),
                key_points=[BriefingPointInput(content="Only one")],
                risks=[BriefingPointInput(content="Risk 1")],
            )
        assert "key_points" in str(exc_info.value)

    def test_minimum_risks_required(self):
        """At least 1 risk is required."""
        with pytest.raises(ValidationError) as exc_info:
            BriefingCreate(
                company_name="Test",
                report_date=date.today(),
                key_points=[
                    BriefingPointInput(content="Point 1"),
                    BriefingPointInput(content="Point 2"),
                ],
                risks=[],
            )
        assert "risks" in str(exc_info.value)

    def test_unique_metric_names(self):
        """Metric names must be unique within a briefing."""
        with pytest.raises(ValidationError) as exc_info:
            BriefingCreate(
                company_name="Test",
                report_date=date.today(),
                key_points=[
                    BriefingPointInput(content="Point 1"),
                    BriefingPointInput(content="Point 2"),
                ],
                risks=[BriefingPointInput(content="Risk 1")],
                metrics=[
                    BriefingMetricInput(metric_name="Revenue", metric_value="100"),
                    BriefingMetricInput(metric_name="revenue", metric_value="200"),  # Duplicate (case insensitive)
                ],
            )
        assert "unique" in str(exc_info.value).lower()

    def test_company_name_required(self):
        """Company name cannot be empty."""
        with pytest.raises(ValidationError):
            BriefingCreate(
                company_name="",
                report_date=date.today(),
                key_points=[
                    BriefingPointInput(content="Point 1"),
                    BriefingPointInput(content="Point 2"),
                ],
                risks=[BriefingPointInput(content="Risk 1")],
            )

    def test_briefing_update_allows_partial(self):
        """Update schema should allow partial updates."""
        data = BriefingUpdate(company_name="New Name")
        assert data.company_name == "New Name"
        assert data.ticker is None
        assert data.key_points is None


class TestBriefingServiceExceptions:
    """Test service layer exceptions."""

    def test_not_found_error_message(self):
        """BriefingNotFoundError should include the ID."""
        briefing_id = uuid.uuid4()
        error = BriefingNotFoundError(briefing_id)
        assert str(briefing_id) in str(error)

    def test_already_published_error_message(self):
        """BriefingAlreadyPublishedError should include the ID."""
        briefing_id = uuid.uuid4()
        error = BriefingAlreadyPublishedError(briefing_id)
        assert str(briefing_id) in str(error)
        assert "published" in str(error).lower()


class TestBriefingToReadSchema:
    """Test the briefing_to_read_schema conversion function."""

    def test_separates_key_points_and_risks(self):
        """The conversion should separate points by type."""
        # Create mock briefing
        mock_briefing = MagicMock()
        mock_briefing.id = uuid.uuid4()
        mock_briefing.company_name = "Test Corp"
        mock_briefing.ticker = "TEST"
        mock_briefing.report_date = date.today()
        mock_briefing.analyst_name = "Analyst"
        mock_briefing.status = "draft"
        mock_briefing.created_at = MagicMock()
        mock_briefing.updated_at = MagicMock()

        # Mock points
        key_point = MagicMock()
        key_point.id = uuid.uuid4()
        key_point.point_type = "key_point"
        key_point.content = "Key insight"
        key_point.sort_order = 0

        risk = MagicMock()
        risk.id = uuid.uuid4()
        risk.point_type = "risk"
        risk.content = "Risk factor"
        risk.sort_order = 0

        mock_briefing.points = [key_point, risk]
        mock_briefing.metrics = []

        result = briefing_to_read_schema(mock_briefing)

        assert len(result.key_points) == 1
        assert len(result.risks) == 1
        assert result.key_points[0]["content"] == "Key insight"
        assert result.risks[0]["content"] == "Risk factor"

    def test_sorts_points_by_order(self):
        """Points should be sorted by sort_order."""
        mock_briefing = MagicMock()
        mock_briefing.id = uuid.uuid4()
        mock_briefing.company_name = "Test"
        mock_briefing.ticker = None
        mock_briefing.report_date = date.today()
        mock_briefing.analyst_name = None
        mock_briefing.status = "draft"
        mock_briefing.created_at = MagicMock()
        mock_briefing.updated_at = MagicMock()
        mock_briefing.metrics = []

        point1 = MagicMock()
        point1.id = uuid.uuid4()
        point1.point_type = "key_point"
        point1.content = "Second"
        point1.sort_order = 1

        point2 = MagicMock()
        point2.id = uuid.uuid4()
        point2.point_type = "key_point"
        point2.content = "First"
        point2.sort_order = 0

        mock_briefing.points = [point1, point2]

        result = briefing_to_read_schema(mock_briefing)

        assert result.key_points[0]["content"] == "First"
        assert result.key_points[1]["content"] == "Second"
