"""
Integration tests for the briefings API.

These tests verify the full request/response cycle through FastAPI.
They use a test database and real HTTP requests via TestClient.
"""
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.db.session import get_db
from app.db.base import Base


# Test database URL (uses same DB but could use separate test DB)
TEST_DATABASE_URL = "postgresql://assessment_user:assessment_pass@localhost:5432/assessment_db"


@pytest.fixture(scope="module")
def test_db():
    """Create a test database session."""
    engine = create_engine(TEST_DATABASE_URL, pool_pre_ping=True)
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    
    # Create tables if they don't exist
    Base.metadata.create_all(bind=engine)
    
    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()
    
    app.dependency_overrides[get_db] = override_get_db
    
    yield TestingSessionLocal
    
    app.dependency_overrides.clear()


@pytest.fixture
def client(test_db):
    """Create a test client."""
    return TestClient(app)


@pytest.fixture
def sample_briefing_data():
    """Sample valid briefing data."""
    return {
        "company_name": "Test Corporation",
        "ticker": "test",
        "report_date": "2024-01-15",
        "analyst_name": "Jane Analyst",
        "key_points": [
            {"content": "Strong quarterly revenue growth of 25%"},
            {"content": "Successful expansion into European markets"},
        ],
        "risks": [
            {"content": "Increasing competition in core markets"},
        ],
        "metrics": [
            {"metric_name": "Revenue", "metric_value": "2.5B", "metric_unit": "USD", "period": "Q4 2023"},
            {"metric_name": "Gross Margin", "metric_value": "42", "metric_unit": "%", "period": "Q4 2023"},
        ],
    }


class TestCreateBriefing:
    """Tests for POST /briefings"""

    def test_create_briefing_success(self, client, sample_briefing_data):
        """Should create a briefing with valid data."""
        response = client.post("/briefings", json=sample_briefing_data)
        
        assert response.status_code == 201
        data = response.json()
        
        assert data["company_name"] == "Test Corporation"
        assert data["ticker"] == "TEST"  # Uppercased
        assert data["status"] == "draft"
        assert len(data["key_points"]) == 2
        assert len(data["risks"]) == 1
        assert len(data["metrics"]) == 2
        assert "id" in data

    def test_create_briefing_missing_company_name(self, client, sample_briefing_data):
        """Should reject briefing without company name."""
        sample_briefing_data["company_name"] = ""
        response = client.post("/briefings", json=sample_briefing_data)
        
        assert response.status_code == 422

    def test_create_briefing_insufficient_key_points(self, client, sample_briefing_data):
        """Should reject briefing with less than 2 key points."""
        sample_briefing_data["key_points"] = [{"content": "Only one"}]
        response = client.post("/briefings", json=sample_briefing_data)
        
        assert response.status_code == 422

    def test_create_briefing_no_risks(self, client, sample_briefing_data):
        """Should reject briefing without risks."""
        sample_briefing_data["risks"] = []
        response = client.post("/briefings", json=sample_briefing_data)
        
        assert response.status_code == 422

    def test_create_briefing_duplicate_metrics(self, client, sample_briefing_data):
        """Should reject briefing with duplicate metric names."""
        sample_briefing_data["metrics"] = [
            {"metric_name": "Revenue", "metric_value": "100"},
            {"metric_name": "revenue", "metric_value": "200"},  # Duplicate
        ]
        response = client.post("/briefings", json=sample_briefing_data)
        
        assert response.status_code == 422


class TestGetBriefing:
    """Tests for GET /briefings/{id}"""

    def test_get_briefing_success(self, client, sample_briefing_data):
        """Should return a briefing by ID."""
        # Create first
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        
        # Get it
        response = client.get(f"/briefings/{briefing_id}")
        
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == briefing_id
        assert data["company_name"] == "Test Corporation"

    def test_get_briefing_not_found(self, client):
        """Should return 404 for non-existent briefing."""
        fake_id = str(uuid.uuid4())
        response = client.get(f"/briefings/{fake_id}")
        
        assert response.status_code == 404

    def test_get_briefing_invalid_uuid(self, client):
        """Should return 400 for invalid UUID format."""
        response = client.get("/briefings/not-a-uuid")
        
        assert response.status_code == 400
        assert "UUID" in response.json()["detail"]


class TestListBriefings:
    """Tests for GET /briefings"""

    def test_list_briefings(self, client, sample_briefing_data):
        """Should list briefings with pagination."""
        # Create a briefing
        client.post("/briefings", json=sample_briefing_data)
        
        response = client.get("/briefings")
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_list_briefings_with_limit(self, client):
        """Should respect limit parameter."""
        response = client.get("/briefings?limit=5")
        
        assert response.status_code == 200
        assert len(response.json()) <= 5

    def test_list_briefings_invalid_limit(self, client):
        """Should reject invalid limit."""
        response = client.get("/briefings?limit=0")
        assert response.status_code == 400
        
        response = client.get("/briefings?limit=101")
        assert response.status_code == 400


class TestUpdateBriefing:
    """Tests for PATCH /briefings/{id}"""

    def test_update_briefing_success(self, client, sample_briefing_data):
        """Should update a draft briefing."""
        # Create
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        
        # Update
        update_data = {"company_name": "Updated Corporation"}
        response = client.patch(f"/briefings/{briefing_id}", json=update_data)
        
        assert response.status_code == 200
        assert response.json()["company_name"] == "Updated Corporation"

    def test_update_published_briefing_fails(self, client, sample_briefing_data):
        """Should not allow updating a published briefing."""
        # Create and publish
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        client.post(f"/briefings/{briefing_id}/generate")
        
        # Try to update
        update_data = {"company_name": "Should Fail"}
        response = client.patch(f"/briefings/{briefing_id}", json=update_data)
        
        assert response.status_code == 409

    def test_update_briefing_not_found(self, client):
        """Should return 404 for non-existent briefing."""
        fake_id = str(uuid.uuid4())
        response = client.patch(f"/briefings/{fake_id}", json={"company_name": "Test"})
        
        assert response.status_code == 404


class TestDeleteBriefing:
    """Tests for DELETE /briefings/{id}"""

    def test_delete_briefing_success(self, client, sample_briefing_data):
        """Should delete a briefing."""
        # Create
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        
        # Delete
        response = client.delete(f"/briefings/{briefing_id}")
        assert response.status_code == 204
        
        # Verify it's gone
        get_response = client.get(f"/briefings/{briefing_id}")
        assert get_response.status_code == 404

    def test_delete_briefing_not_found(self, client):
        """Should return 404 for non-existent briefing."""
        fake_id = str(uuid.uuid4())
        response = client.delete(f"/briefings/{fake_id}")
        
        assert response.status_code == 404


class TestGenerateReport:
    """Tests for POST /briefings/{id}/generate"""

    def test_generate_report_success(self, client, sample_briefing_data):
        """Should publish a briefing."""
        # Create
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        
        # Generate/Publish
        response = client.post(f"/briefings/{briefing_id}/generate")
        
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "published"
        assert data["message"] == "Report generated successfully"

    def test_generate_report_idempotent(self, client, sample_briefing_data):
        """Calling generate multiple times should be safe."""
        # Create and publish
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        
        # Generate twice
        response1 = client.post(f"/briefings/{briefing_id}/generate")
        response2 = client.post(f"/briefings/{briefing_id}/generate")
        
        assert response1.status_code == 200
        assert response2.status_code == 200

    def test_generate_report_not_found(self, client):
        """Should return 404 for non-existent briefing."""
        fake_id = str(uuid.uuid4())
        response = client.post(f"/briefings/{fake_id}/generate")
        
        assert response.status_code == 404


class TestGetBriefingHtml:
    """Tests for GET /briefings/{id}/html"""

    def test_get_html_success(self, client, sample_briefing_data):
        """Should return HTML report."""
        # Create
        create_response = client.post("/briefings", json=sample_briefing_data)
        briefing_id = create_response.json()["id"]
        
        # Get HTML
        response = client.get(f"/briefings/{briefing_id}/html")
        
        assert response.status_code == 200
        assert response.headers["content-type"] == "text/html; charset=utf-8"
        
        html = response.text
        assert "Test Corporation" in html
        assert "Strong quarterly revenue" in html
        assert "Increasing competition" in html

    def test_get_html_not_found(self, client):
        """Should return 404 for non-existent briefing."""
        fake_id = str(uuid.uuid4())
        response = client.get(f"/briefings/{fake_id}/html")
        
        assert response.status_code == 404
